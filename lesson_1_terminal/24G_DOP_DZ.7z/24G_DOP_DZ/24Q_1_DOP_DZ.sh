#! /bin/bash
 # скрипт который выполнит автоматически пункты 3, 4, 5, 6, 7, 8, 13
 mkdir dp;
 cd dp;
 mkdir less_1 less_2 less_3; 
 cd less_3;
 touch 11.txt 12.txt 13.txt 11.json 12.json; 
 mkdir mur_1 mur_2 mur_3;
 ls; 
  mv 11.txt 11.json mur_2/.
